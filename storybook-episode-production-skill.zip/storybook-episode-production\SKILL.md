---
name: storybook-episode-production
description: Produce or revise illustrated children's storybook episodes from scripts, series rulebooks, character/background references, and prior episode folders. Use when the user asks to create a new episode, prepare episode references, generate page images, add text panels, regenerate selected pages, or package final storybook image assets while preserving series continuity and avoiding contamination from earlier attempts.
---

# Storybook Episode Production

Use this skill for repeatable illustrated episode work: script intake, reference audit, image planning, generation, text-panel passes, QA, and final folder assembly.

Do not use this for generic one-off image requests; use the installed image generation skill for those.

## Inputs To Find

- Episode script or outline, usually a `.md` file from Downloads or the series folder.
- Series root, usually under a `storybooks` workspace.
- Series docs: character sheets, image-generation rules, design rules, location/background notes, and naming conventions.
- Reference images for all characters, new locations, props, and recurring visual elements. Treat these images, not text descriptions, as the source of visual truth.
- Prior generated attempts only as process history; do not use failed or superseded episode images as visual references unless the user explicitly approves them.

## Workflow

1. Load the image generation skill before any visual generation.
2. Inspect the series folder and docs. Identify the official rulebook, character sheets, background references, and existing episode folder conventions.
3. Read the script and create a page plan: page number, scene summary, characters, background, required text, and reference images.
4. Audit coverage before generating:
   - Every named character has an official visual reference.
   - Every new location or important prop has either an official reference or a clearly stated generation plan.
   - Text box style and placement rules are known.
   - Output folder and filename pattern are known.
5. If references are missing but the episode is still feasible, create only the missing reference assets first and stop with a clear handoff for the main episode pass.
6. Generate page images from the original reference images, not from text descriptions alone. Use text prompts only to describe the scene action, composition, and required changes; do not infer character or location appearance from prose when a reference image exists. Keep prompts page-specific and explicitly exclude prior failed episode content.
7. For pages with in-image text, run a separate text-panel pass when needed. Preserve the approved illustration as much as possible and change only the panel/text.
8. QA every page:
   - Character identity matches the official sheets.
   - Recurring locations match the series references.
   - No content from unrelated prior episodes appears.
   - Text is correct, readable, and not misspelled.
   - Text panels follow the current rulebook.
   - Page count and filenames match the script.
9. Regenerate only the smallest failing unit: one page, one character reference, or one text panel.
10. Assemble a `final` folder or the series-standard final location with stable `00_...` page filenames.
11. Report the script path, final folder, page count, any known imperfect pages, and the exact pages regenerated.

## Guardrails

- Treat official character sheets and design rulebooks as higher priority than generated attempts.
- Never rely on script text, prompt text, or memory as the visual source for characters, locations, props, or text-panel style when an original reference image exists. Attach or inspect the original reference image and preserve its actual shapes, colors, proportions, materials, and defining details.
- Do not let visual details from earlier episode folders bleed into a new episode unless the script calls for them.
- Keep original images when making text variants; write variants with an explicit suffix such as `_text` or the series-standard Korean suffix.
- If the generator repeatedly misspells a proper noun, keep the last good visual candidate separate and tell the user which file is a candidate rather than silently replacing the final.
- Do not overwrite a final page until the replacement is clearly better on the requested criterion.

## Output

End with a concise production note:

- `script`: path used.
- `references`: key official references used or missing.
- `final`: output folder.
- `pages`: count and filename range.
- `qa`: pass/fail notes for character identity, text, and contamination.
